This module extends the functionality of Purchase Orders to support a tier
validation process.
