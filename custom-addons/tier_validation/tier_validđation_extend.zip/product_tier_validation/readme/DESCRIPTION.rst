Adds an approval workflow to Products.
The default rule requires new Product to be approved
before they can be used.

For this, the new Product record is kept as "Archived" until it is approved.
