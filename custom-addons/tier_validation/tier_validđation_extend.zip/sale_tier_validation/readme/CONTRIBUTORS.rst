* Mayank Gosai <mgosai@opensourceintegrators.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Sergio Teruel

* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
