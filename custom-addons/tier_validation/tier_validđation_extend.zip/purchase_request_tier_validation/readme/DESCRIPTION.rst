This module extends the functionality of Purchase Requests to support a tier validation process.
