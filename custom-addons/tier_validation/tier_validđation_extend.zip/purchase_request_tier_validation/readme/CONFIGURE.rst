A default tier is created allowing Purchase Request Manager to approve Purchase
Requests.

In addition, you may want to add more tiers, so:

#. Go to *Settings > Technical > Tier Validations > Tier Definition*.
#. Create as many tiers as you want for Purchase Order model.
